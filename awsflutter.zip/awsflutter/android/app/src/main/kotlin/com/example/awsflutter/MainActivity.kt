package com.example.awsflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
