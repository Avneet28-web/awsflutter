import 'dart:async';

import 'package:flutter/material.dart';

void main() {
  runApp(const DigitalPictureFrameApp());
}

class DigitalPictureFrameApp extends StatelessWidget {
  const DigitalPictureFrameApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Digital Picture Frame',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const PictureFrameScreen(),
    );
  }
}

class PictureFrameScreen extends StatefulWidget {
  const PictureFrameScreen({super.key});

  @override
  State<PictureFrameScreen> createState() => _PictureFrameScreenState();
}

class _PictureFrameScreenState extends State<PictureFrameScreen> {
  final List<String> _imageUrls = [
    // Replace these with your actual S3 URLs
    'https://avneetawsbucket.s3.us-east-1.amazonaws.com/pic1.jpg',
    'https://avneetawsbucket.s3.us-east-1.amazonaws.com/pic2.jpg',
    'https://avneetawsbucket.s3.us-east-1.amazonaws.com/pic3.jpg',
    'https://avneetawsbucket.s3.us-east-1.amazonaws.com/pic4.jpg',
  ];

  int _currentImageIndex = 0;
  bool _isPaused = false;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startImageRotation();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void _startImageRotation() {
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (!_isPaused) {
        setState(() {
          _currentImageIndex = (_currentImageIndex + 1) % _imageUrls.length;
        });
      }
    });
  }

  void _togglePause() {
    setState(() {
      _isPaused = !_isPaused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Digital Picture Frame'),
      ),
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.blueAccent,
              width: 8.0,
            ),
            borderRadius: BorderRadius.circular(16.0),
          ),
          padding: const EdgeInsets.all(8.0),
          child: _imageUrls.isNotEmpty
              ? Image.network(
                  _imageUrls[_currentImageIndex],
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      const Text('Error loading image'),
                )
              : const Text('No images available'),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _togglePause,
        tooltip: _isPaused ? 'Resume' : 'Pause',
        child: Icon(_isPaused ? Icons.play_arrow : Icons.pause),
      ),
    );
  }
}
